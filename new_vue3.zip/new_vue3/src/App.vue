<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <h1>EPUB 阅读器</h1>
    <div class="upload-section">
      <input type="file" @change="handleFileUpload" accept=".epub" class="file-input">
      <button @click="uploadFile" :disabled="loading" class="upload-button">
        {{ loading ? '上传中...' : '上传 EPUB' }}
      </button>
      <p v-if="uploadMessage" :class="{ 'success-message': uploadMessage.includes('成功'), 'error-message': uploadMessage.includes('失败') }">{{ uploadMessage }}</p>
    </div>

    <h2>已上传的 EPUB 文件:</h2>
    <ul v-if="files.length > 0" class="file-list">
      <li v-for="(file, index) in files" :key="index" class="file-list-item" @click="loadEpub(file)">
        {{ file }}
      </li>
    </ul>
    <p v-else class="no-files-message">暂无已上传的 EPUB 文件。</p>

    <div v-if="currentBookFile" class="reader-container">
      <h3>正在阅读: {{ currentBookFile }}</h3>
      <div id="viewer" class="epub-viewer"></div>
      <div class="navigation-buttons">
        <button @click="prevPage" class="nav-button">上一页</button>
        <button @click="nextPage" class="nav-button">下一页</button>
      </div>
    </div>

    <!-- <HelloWorld msg="Welcome to Your Vue.js App"/> -->
  </div>
</template>

<script>
import axios from 'axios';
import ePub from 'epubjs'; // 直接导入epub.js的默认导出

export default {
  name: 'App',
  components: {
    // HelloWorld // 暂时注释掉，如果不需要可以删除
  },
  data() {
    return {
      selectedFile: null,
      loading: false,
      uploadMessage: '',
      files: [],
      currentBookFile: null, // 当前正在阅读的书籍文件名
      book: null,           // epubjs Book 对象
      rendition: null       // epubjs Rendition 对象
    };
  },
  methods: {
    handleFileUpload(event) {
      this.selectedFile = event.target.files[0];
      this.uploadMessage = '';
    },
    async uploadFile() {
      if (!this.selectedFile) {
        this.uploadMessage = '请选择一个EPUB文件进行上传。';
        return;
      }

      this.loading = true;
      this.uploadMessage = '上传中...';
      const formData = new FormData();
      formData.append('file', this.selectedFile);

      try {
        const response = await axios.post('http://localhost:8080/uploadEpub', formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });
        this.uploadMessage = response.data;
        this.selectedFile = null;
        this.fetchEpubFiles();
      } catch (error) {
        console.error('文件上传失败:', error);
        this.uploadMessage = '文件上传失败。';
      } finally {
        this.loading = false;
      }
    },
    async fetchEpubFiles() {
      try {
        const response = await axios.get('http://localhost:8080/listEpubs');
        this.files = response.data;
      } catch (error) {
        console.error('获取EPUB文件列表失败:', error);
        this.files = [];
      }
    },
    async loadEpub(filename) {
      this.currentBookFile = filename;
      // 后端提供文件内容的URL
      const epubUrl = `http://localhost:8080/epub/${encodeURIComponent(filename)}`;

      if (this.rendition) {
        this.rendition.destroy(); // 销毁之前的渲染实例
      }

      this.book = ePub(epubUrl);
      this.rendition = this.book.renderTo("viewer", {
        width: "100%",
        height: 600, // 阅读器高度，可根据需要调整
        manager: "continuous", // 连续滚动模式，或 "default" (分页)
        flow: "paginated" // 分页模式，或 "scrolled" (滚动)
      });

      this.rendition.display();

      // 可选：添加键盘事件监听器进行导航
      this.rendition.on("keyup", (event) => {
        if (event.key === "ArrowLeft") {
          this.prevPage();
        } else if (event.key === "ArrowRight") {
          this.nextPage();
        }
      });
    },
    prevPage() {
      if (this.rendition) {
        this.rendition.prev();
      }
    },
    nextPage() {
      if (this.rendition) {
        this.rendition.next();
      }
    }
  },
  mounted() {
    this.fetchEpubFiles();
  }
}
</script>

<style>
body {
  margin: 0;
  background-color: #f4f7f6;
}

#app {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #333;
  margin-top: 60px;
  max-width: 800px;
  margin-left: auto;
  margin-right: auto;
  padding: 30px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

h1 {
  color: #4a90e2;
  margin-bottom: 30px;
}

h2 {
  color: #555;
  margin-top: 40px;
  margin-bottom: 20px;
}

.upload-section {
  margin-bottom: 30px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 15px;
}

.file-input {
  border: 1px solid #ccc;
  padding: 10px;
  border-radius: 5px;
  width: 100%;
  max-width: 300px;
}

.upload-button {
  background-color: #4CAF50;
  color: white;
  padding: 12px 25px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 1em;
  transition: background-color 0.3s ease;
}

.upload-button:hover:not(:disabled) {
  background-color: #45a049;
}

.upload-button:disabled {
  background-color: #cccccc;
  cursor: not-allowed;
}

.upload-message {
  margin-top: 15px;
  font-weight: bold;
}

.success-message {
  color: #28a745;
}

.error-message {
  color: #dc3545;
}

.file-list {
  list-style-type: none;
  padding: 0;
  max-width: 400px;
  margin: 0 auto 30px auto;
  border: 1px solid #eee;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.file-list-item {
  background-color: #f9f9f9;
  padding: 12px 15px;
  border-bottom: 1px solid #eee;
  text-align: left;
  font-size: 0.95em;
  color: #555;
  cursor: pointer; /* Indicate it's clickable */
  transition: background-color 0.2s ease;
}

.file-list-item:hover {
  background-color: #eef;
}

.file-list-item:last-child {
  border-bottom: none;
}

.no-files-message {
  color: #777;
  font-style: italic;
  margin-bottom: 30px;
}

img[alt="Vue logo"] {
  width: 100px;
  margin-bottom: 20px;
}

/* New styles for reader */
.reader-container {
  margin-top: 50px;
  padding: 20px;
  border: 1px solid #e0e0e0;
  border-radius: 10px;
  background-color: #fcfcfc;
  box-shadow: inset 0 2px 5px rgba(0,0,0,0.05);
}

.epub-viewer {
  margin-top: 20px;
  border: 1px solid #ddd;
  background-color: #fff;
  overflow: hidden;
}

.navigation-buttons {
  margin-top: 20px;
  display: flex;
  justify-content: center;
  gap: 15px;
}

.nav-button {
  background-color: #007bff;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 0.95em;
  transition: background-color 0.3s ease;
}

.nav-button:hover {
  background-color: #0056b3;
}
</style>
